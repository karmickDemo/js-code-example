import React, { Component } from 'react';
import {Route} from 'react-router-dom';

import './matchinterior.css';

import asyncComponent from "../AsyncComponent";
/*import Banner from '../banner/banner';
import HeaderBar from '../headerbar/headerbar';
import MainEvent from '../mainevent/mainevent';
import Commentaries from '../commentries/commentries';
import TopPlayers from '../topplayers/topplayers';
import BallPossesion from '../ballpossesion/ballpossesion';
import Positions from '../positions/positions';
import Formation from '../formation/formation';
import Lastfivematches from '../lastfivematches/lastfivematches';
import Facetoface from '../facetoface/facetoface';*/

const Banner = asyncComponent(() => import('../banner/banner'));
const HeaderBar = asyncComponent(() => import('../headerbar/headerbar'));
const MainEvent = asyncComponent(() => import('../mainevent/mainevent'));
const Commentaries = asyncComponent(() => import('../commentries/commentries'));
const TopPlayers = asyncComponent(() => import('../topplayers/topplayers'));
const BallPossesion = asyncComponent(() => import('../ballpossesion/ballpossesion'));
const Positions = asyncComponent(() => import('../positions/positions'));
const Formation = asyncComponent(() => import('../formation/formation'));
const Lastfivematches = asyncComponent(() => import('../lastfivematches/lastfivematches'));
const Facetoface = asyncComponent(() => import('../facetoface/facetoface'));

const ViewMoreButton = (props) => (
  <Route render={({ history}) => (
    <button
		type='button'
		className="btn btn-outline-primary viewmore"
		onClick={() => { history.push({pathname: `/innerpages/${props.path}`, state:{selected:props.path}})}} >
		View More
	  </button>
  )} />
)

class MatchInterior extends Component {
	
	constructor(props) {
		super(props);
		
		this.state = {
			loaded: false,
			'team1id': window.localStorage.getItem('team1'),
			'team2id': window.localStorage.getItem('team2')
		}
	}
	
	componentWillMount() {
		setTimeout(() => {
			this.setState({loaded: true});
		}, 10000);
	}
	
	render() {
		return (
			<div className="MatchInterior">
				<HeaderBar pagepath={this.props.location.pathname}/>
				
				<main className="App-body">
					<Banner />
					<section className="section-title">Main Event</section>
					<MainEvent displayrow={2} />
					<ViewMoreButton path='MainEvent' />
					
					<section className="section-title">Ball Possesion</section>
					<BallPossesion partial={true}/>
					<ViewMoreButton path='BallPossesion' />
					
					<section className="section-title">Formations</section>
					<Formation partial={true}/>					
					<ViewMoreButton path='Formation' />
					
					<section className="section-title">Positions</section>
					<Positions partial={true}/>
					<ViewMoreButton path='Positions' />
					
					{/*<section className="section-title">Commentaries</section>
					<Commentaries />
					<ViewMoreButton path='Commentaries' />*/}
					
					{/*<section className="section-title">Top Players</section>
					<TopPlayers />
					<ViewMoreButton path='TopPlayers' />*/}
					
					<section className="section-title">Last Matches</section>
					<Lastfivematches partial={true}/>
					<ViewMoreButton path='Lastfivematches' />
					
					<section className="section-title">Face to Face</section>
					<Facetoface partial={true} />
					<ViewMoreButton path='Facetoface' />
				</main>
			</div>
		)
	}
}

export default MatchInterior;