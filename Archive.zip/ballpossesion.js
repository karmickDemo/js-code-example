import React, { Component } from 'react';
import { Chart } from 'react-google-charts';
import axios from 'axios';
import queryString from 'query-string';

import './ballpossesion.css';
/*import matchinfo from '../../jsondata/matchinfo.json';*/

import DBPromise from '../dbpromise/DBPromise';
const dbBallposs = new DBPromise({dbname: 'ballpossn', ver: 1, keypath:'matchid'});

export default class BallPossesion extends Component {
	
	constructor(props){
		super(props);
		
		this.state = {
			league: localStorage.getItem('league'),
			logo: {
				teamA: null,
				teamB: null
			},
			
			passes: {
				correct_A: 0,
				incorrect_A: 5,
				correct_B: 30,
				incorrect_B: 50,
				total_A: 100,
				total_B: 200,
			},
			
			possesion: {
				teamA: 50,
				teamB: 50
			},
			
			shots: {
				off_target_A: 0,
				woodwork_A: 0,
				on_goal_A: 0,
				off_target_B: 0,
				woodwork_B: 0,
				on_goal_B: 0
			},
			
			goals: {
				field_A: 0,
				own_A: 0,
				headed_A: 0,
				fkick_A: 0,
				penalty_A: 0,
				field_B: 0,
				own_B: 0,
				headed_B: 0,
				fkick_B: 0,
				penalty_B: 0,
			},
			
			corners: {
				cornerA:0,
				cornerB:0
			},
			
			fouls: {
				foulA: 0,
				foulB: 0
			},
			
			defending: {
				interception_A: 0,
				clearance_A: 0,
				interception_B: 0,
				clearance_B: 0
			},
			
			cards: {
				yellow_A: 0,
				red_A: 0,
				yellow_B: 0,
				red_B: 0
			}
		}
	}
	
	componentWillMount(){		
		let corrctPasses_A = 0;
		let incorrctPasses_A = 0;
		let corrctPasses_B = 0;
		let incorrctPasses_B = 0;
		let totalPases_A = 0;
		let totalPases_B = 0;
		
		let off_target_A = 0;
		let woodwork_A = 0;
		let on_goal_A = 0;
		let off_target_B = 0;
		let woodwork_B = 0;
		let on_goal_B = 0;
		
		let field_A = 0;
		let own_A = 0;
		let headed_A = 0;
		let fkick_A = 0;
		let penalty_A = 0;
		let field_B = 0;
		let own_B = 0;
		let headed_B = 0;
		let fkick_B = 0;
		let penalty_B = 0;
		
		let cornerA = 0;
		let cornerB = 0;
		
		let foulA = 0;
		let foulB = 0;
		
		let interception_A = 0;
		let clearance_A = 0;
		let interception_B = 0;
		let clearance_B = 0;
		
		let yellow_A = 0;
		let red_A = 0;
		let yellow_B = 0;
		let red_B = 0;
		
		dbBallposs.getLocalEventData('ballpossn', window.localStorage.getItem('matchid'))
		.then(offlinedata =>{
			
			//console.log('offlinedata', JSON.stringify(offlinedata));
			
			if(offlinedata){
				//console.log(offlinedata.teamA.id);
				
				this.setState({
					logo: offlinedata.logo,
					passes: offlinedata.passes,
					possesion: offlinedata.possesion,
					shots: offlinedata.shots,
					goals: offlinedata.goals,
					corners: offlinedata.corners,
					fouls: offlinedata.fouls,
					defending: offlinedata.defending,
					cards: offlinedata.cards
				});
				
			} else {
				//console.log("no data found")
			}
		})
		
		axios({
			method: 'post',
			url: 'https://pwa.popular.tv/api/ficha.php',
			mode: 'no-cors',
			data: queryString.stringify({league: this.state.league, match_id: window.localStorage.getItem('matchid')}),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		})
		.then((res) => {
			if(res.data.success === true) {
				const matchinfo = res.data.data;
				//console.log(JSON.stringify(matchinfo));
				
				const teamA = matchinfo.Match.Teams.Team[0]._teamId;
				const teamB = matchinfo.Match.Teams.Team[1]._teamId;
				
				this.setState({
					logo: {
						teamA: 'https://estadisticas.popular.tv/porftp/minutoaminuto/html/escudos_ch/'+teamA+'.gif',
						teamB: 'https://estadisticas.popular.tv/porftp/minutoaminuto/html/escudos_ch/'+teamB+'.gif'
					}
				});
				
				matchinfo.Match.Incidences.Incidence.map((incidence) => {
		
					// ----- passes -----
					if(incidence._typeId === '180' && incidence._teamId === teamA){
						corrctPasses_A += 1;
					}
					
					if(incidence._typeId === '181' && incidence._teamId === teamA){
						incorrctPasses_A += 1;
					}
					
					if(incidence._typeId === '180' && incidence._teamId === teamB){
						corrctPasses_B += 1;
					}
					
					if(incidence._typeId === '181' && incidence._teamId === teamB){
						incorrctPasses_B += 1;
					}
					
					//---- shots -----
					if(incidence._typeId === '33' && incidence._teamId === teamA){
						off_target_A += 1;
					}
					
					if(incidence._typeId === '34' && incidence._teamId === teamA){
						woodwork_A += 1;
					}
					
					if(incidence._typeId === '35' && incidence._teamId === teamA){
						on_goal_A += 1;
					}
					
					if(incidence._typeId === '33' && incidence._teamId === teamB){
						off_target_B += 1;
					}
					
					if(incidence._typeId === '34' && incidence._teamId === teamB){
						woodwork_B += 1;
					}
					
					if(incidence._typeId === '35' && incidence._teamId === teamB){
						on_goal_B += 1;
					}
					
					// --- goals----
					if(incidence._typeId === '9' && incidence._teamId === teamA){
						field_A += 1;
					}
					
					if(incidence._typeId === '10' && incidence._teamId === teamA){
						own_A += 1;
					}
					
					if(incidence._typeId === '11' && incidence._teamId === teamA){
						headed_A += 1;
					}
					
					if(incidence._typeId === '12' && incidence._teamId === teamA){
						fkick_A += 1;
					}
					
					if(incidence._typeId === '13' && incidence._teamId === teamA){
						penalty_A += 1;
					}
					
					if(incidence._typeId === '9' && incidence._teamId === teamB){
						field_B += 1;
					}
					
					if(incidence._typeId === '10' && incidence._teamId === teamB){
						own_B += 1;
					}
					
					if(incidence._typeId === 11 && incidence._teamId === teamB){
						headed_B += 1;
					}
					
					if(incidence._typeId === '12' && incidence._teamId === teamB){
						fkick_B += 1;
					}
					
					if(incidence._typeId === '13' && incidence._teamId === teamB){
						penalty_B += 1;
					}
					
					// ---- corners ----
					if(incidence._typeId === '28' && incidence._teamId === teamA){
						cornerA += 1;
					}
					if(incidence._typeId === '28' && incidence._teamId === teamB){
						cornerB += 1;
					}
					
					// ----- fouls----
					if(incidence._typeId === '36' && incidence._teamId === teamA){
						foulA += 1;
					}
					if(incidence._typeId === '36' && incidence._teamId === teamB){
						foulB += 1;
					}
					
					// ---- defending -----
					if(incidence._typeId === '182' && incidence._teamId === teamA){  //interception
						interception_A += 1;
					}
					if(incidence._typeId === '182' && incidence._teamId === teamB){
						interception_B += 1;
					}
					
					if(incidence._typeId === '29' || incidence._typeId === '30' && incidence._teamId === teamA){  //clearance
						clearance_A += 1;
					}
					if(incidence._typeId === '29' || incidence._typeId === '30' && incidence._teamId === teamB){
						clearance_B += 1;
					}
					
					// ---- cards ----
					if(incidence._typeId === '3' && incidence._teamId === teamA){ //yellow
						yellow_A += 1;
					}
					if(incidence._typeId === '4' || incidence._typeId === '5' && incidence._teamId === teamA){ //red
						red_A += 1;
					}
					
					if(incidence._typeId === '3' && incidence._teamId === teamB){ //yellow
						yellow_B += 1;
					}
					if(incidence._typeId === '4' || incidence._typeId === '5' && incidence._teamId === teamB){ //red
						red_B += 1;
					}
					
				});
				
				totalPases_A = corrctPasses_A + incorrctPasses_A;
				totalPases_B = corrctPasses_B + incorrctPasses_B;
				
				this.setState({
					passes: {
						correct_A: corrctPasses_A,
						incorrect_A: incorrctPasses_A,
						correct_B: corrctPasses_B,
						incorrect_B: incorrctPasses_B,
						total_A: totalPases_A,
						total_B: totalPases_B,
					},
					
					possesion: {
						teamA: Number(matchinfo.Match.Teams.Team[0].TeamStats._ballPossession),
						teamB: Number(matchinfo.Match.Teams.Team[1].TeamStats._ballPossession)
					},
					
					shots: {
						off_target_A: off_target_A,
						woodwork_A: woodwork_A,
						on_goal_A: on_goal_A,
						off_target_B: off_target_B,
						woodwork_B: woodwork_B,
						on_goal_B: on_goal_B
					},
					
					goals: {
						field_A: field_A,
						own_A: own_A,
						headed_A: headed_A,
						fkick_A: fkick_A,
						penalty_A: penalty_A,
						field_B: field_B,
						own_B: own_B,
						headed_B: headed_B,
						fkick_B: fkick_B,
						penalty_B: penalty_B,
					},
					
					corners: {
						cornerA:cornerA,
						cornerB:cornerB
					},
					
					fouls: {
						foulA: foulA,
						foulB: foulB
					},
					
					defending: {
						interception_A: interception_A,
						clearance_A: clearance_A,
						interception_B: interception_B,
						clearance_B: clearance_B,
					},
					
					cards: {
						yellow_A: yellow_A,
						red_A: red_A,
						yellow_B: yellow_B,
						red_B: red_B
					}
				}, function(){
				
					let stateData = [{matchid: window.localStorage.getItem('matchid'), logo: this.state.logo, passes: this.state.passes, possesion: this.state.possesion, shots: this.state.shots, goals: this.state.goals, corners: this.state.corners, fouls: this.state.fouls, defending: this.state.defending, cards: this.state.cards}];
					
					dbBallposs.saveEventDataLocally(stateData, 'ballpossn', false);
				})
			}
		})
		.catch((error) => {
			console.log(error.response)
		});

	}
	
	render(){
		
		function ShowAllElements(props){
			const partial = props.partial;
			const state = props.state;
			
			const passesPercentage_A = Math.floor((state.passes.correct_A/state.passes.total_A)*100);
			const passesPercentage_B = Math.floor((state.passes.correct_B/state.passes.total_B)*100);
			
			let totalShots_A = state.shots.off_target_A + state.shots.woodwork_A + state.shots.on_goal_A;
			let totalShots_B = state.shots.off_target_B + state.shots.woodwork_B + state.shots.on_goal_B;
			
			let totalShotsPernc_A = (totalShots_A!==0 || totalShots_B!==0)?Math.floor((totalShots_A/(totalShots_A + totalShots_B))*100):50;
			let totalShotsPernc_B = (totalShots_A!==0 || totalShots_B!==0)?Math.floor((totalShots_B/(totalShots_A + totalShots_B))*100):50;

			let totalGoals_A = state.goals.field_A + state.goals.headed_A + state.goals.fkick_A + state.goals.penalty_A + state.goals.own_B;
			let totalGoals_B = state.goals.field_B + state.goals.headed_B + state.goals.fkick_B + state.goals.penalty_B + state.goals.own_A;
			
			let goal_percen_A = (totalGoals_A!==0 || totalGoals_B!==0)?Math.floor((totalGoals_A/(totalGoals_A + totalGoals_B))*100):50;
			let goal_percen_B = (totalGoals_A!==0 || totalGoals_B!==0)?Math.floor((totalGoals_B/(totalGoals_A + totalGoals_B))*100):50;
			
			let corner_percent_A = (state.corners.cornerA!==0 || state.corners.cornerb!==0)?Math.floor((state.corners.cornerA/(state.corners.cornerA + state.corners.cornerB))*100):50;
			let corner_percent_B = (state.corners.cornerA!==0 || state.corners.cornerb!==0)?Math.floor((state.corners.cornerB/(state.corners.cornerA + state.corners.cornerB))*100):50;
			
			let foul_percent_A = (state.fouls.foulA!==0 || state.fouls.foulb!==0)?Math.floor((state.fouls.foulA/(state.fouls.foulA + state.fouls.foulB))*100):50;
			let foul_percent_B = (state.fouls.foulA!==0 || state.fouls.foulb!==0)?Math.floor((state.fouls.foulB/(state.fouls.foulA + state.fouls.foulB))*100):50;
			
			let accuracy_percntg_A = (state.shots.on_goal_A!==0 || state.shots.on_goal_b!==0)?Math.floor((state.shots.on_goal_A/(state.shots.on_goal_A + state.shots.on_goal_B)*100)):50;
			let accuracy_percntg_B = (state.shots.on_goal_A!==0 || state.shots.on_goal_b!==0)?Math.floor((state.shots.on_goal_B/(state.shots.on_goal_A + state.shots.on_goal_B)*100)):50;
			
			let int_pcntg_A = (state.defending.interception_A!==0 || state.defending.interception_b!==0)?Math.floor((state.defending.interception_A/(state.defending.interception_A + state.defending.interception_B))*100):50;
			let int_pcntg_B = (state.defending.interception_A!==0 || state.defending.interception_b!==0)?Math.floor((state.defending.interception_B/(state.defending.interception_A + state.defending.interception_B))*100):50;
			
			let clren_pcntg_A = (state.defending.clearance_A!==0 || state.defending.clearance_B!==0)?Math.floor((state.defending.clearance_A/(state.defending.clearance_A + state.defending.clearance_B))*100):50;
			
			let clren_pcntg_B = (state.defending.clearance_A!==0 || state.defending.clearance_B!==0)?Math.floor((state.defending.clearance_B/(state.defending.clearance_A + state.defending.clearance_B))*100):50;
			
			let yellow_pcntg_A = (state.cards.yellow_A!==0 || state.cards.yellow_B!==0)?Math.floor((state.cards.yellow_A/(state.cards.yellow_A + state.cards.yellow_B))*100):50;
			let yellow_pcntg_B = (state.cards.yellow_A!==0 || state.cards.yellow_B!==0)?Math.floor((state.cards.yellow_B/(state.cards.yellow_A + state.cards.yellow_B))*100):50;
			
			let red_pcntg_A = (state.cards.red_A!==0 || state.cards.red_B!==0)?Math.floor((state.cards.red_A/(state.cards.red_A + state.cards.red_B))*100):50;
			let red_pcntg_B = (state.cards.red_A!==0 || state.cards.red_B!==0)?Math.floor((state.cards.red_B/(state.cards.red_A + state.cards.red_B))*100):50;

			if(partial === false || partial === undefined){
				return(
					<div>
						<section className="section-title">Possesion</section>
						
						<ShowStatistics state={state} />
						
						<div className="matchsummary-heading">
							<img src={state.logo.teamA} className="formtn-img" alt="team logo" />
							<span className="title">Match Summary</span>
							<img src={state.logo.teamB} className="formtn-img" alt="team logo" />
						</div>
						
						<div className="matchsummary">
							<div className="summary-title">Total Shots</div>
							<div className="team-percentage team-1-bar" style={{width: totalShotsPernc_A + '%'}}><span>{totalShots_A}</span></div>
							<div className="team-percentage team-2-bar" style={{width: totalShotsPernc_B + '%'}}><span>{totalShots_B}</span></div>
						</div>
						
						<div className="matchsummary">
							<div className="summary-title">Goals</div>
							<div className="team-percentage team-1-bar" style={{width: goal_percen_A+'%'}}><span>{totalGoals_A}</span></div>
							<div className="team-percentage team-2-bar" style={{width: goal_percen_B+'%'}}><span>{totalGoals_B}</span></div>
						</div>
						
						<div className="matchsummary">
							<div className="summary-title">Corners</div>
							<div className="team-percentage team-1-bar" style={{width: corner_percent_A+'%'}}><span>{state.corners.cornerA}</span></div>
							<div className="team-percentage team-2-bar" style={{width: corner_percent_B+'%'}}><span>{state.corners.cornerB}</span></div>
						</div>
						
						<div className="matchsummary">
							<div className="summary-title">Fouls</div>
							<div className="team-percentage team-1-bar" style={{width: foul_percent_A+'%'}}><span>{state.fouls.foulA}</span></div>
							<div className="team-percentage team-2-bar" style={{width: foul_percent_B+'%'}}><span>{state.fouls.foulB}</span></div>
						</div>
						
						<section className="section-title">Attacks</section>
						<div className="sub-title">
							<div className="sub-sectiontitle-1">Shots</div>
							<div className="sub-sectiontitle-2">On goal / Total</div>
						</div>
						
						{/*<div className="box-module">
							<div className="team-box">
								<img src={state.logo.teamA} className="box-module-img" alt="team logo" />
								<div className="activity-percentage">{accuracy_percntg_A}%</div>
								<div className="activity-percentage-2">{state.shots.on_goal_A}/{state.shots.on_goal_A + state.shots.on_goal_B}</div>
							</div>
							
							<div className="team-box">
								<img src={state.logo.teamB} className="box-module-img" alt="team logo" />
								<div className="activity-percentage">{accuracy_percntg_B}%</div>
								<div className="activity-percentage-2">{state.shots.on_goal_B}/{state.shots.on_goal_A + state.shots.on_goal_B}</div>
							</div>
						</div>*/}
						
						<div className="box-module">
							<div className="team-box">
								<img src={state.logo.teamA} className="box-module-img" alt="team logo" />
								<div className="activity-percentage">{totalShotsPernc_A}%</div>
								<div className="activity-percentage-2">{totalShots_A}/{totalShots_A + totalShots_B}</div>
							</div>
							
							<div className="team-box">
								<img src={state.logo.teamB} className="box-module-img" alt="team logo" />
								<div className="activity-percentage">{totalShotsPernc_B}%</div>
								<div className="activity-percentage-2">{totalShots_B}/{totalShots_A + totalShots_B}</div>
							</div>
						</div>
						
						{/*<div className="matchsummary">
							<div className="summary-title">Blocked Shots</div>
							<div className="team-percentage team-1-bar" style={{width: '100%'}}><span>1</span></div>
							<div className="team-percentage team-2-bar" style={{width: '0%'}}><span>0</span></div>
						</div>*/}
						
						<section className="section-title">Passes</section>
						<div className="sub-title">
							<div className="sub-sectiontitle-1">Passes</div>
							<div className="sub-sectiontitle-2">Successful / Total</div>
						</div>
						
						<div className="box-module">
							<div className="team-box">
								<img src={state.logo.teamA} className="box-module-img" alt="team logo" />
								<div className="activity-percentage">{passesPercentage_A}%</div>
								<div className="activity-percentage-2">{state.passes.correct_A}/{state.passes.total_A}</div>
							</div>
							
							<div className="team-box">
								<img src={state.logo.teamB} className="box-module-img" alt="team logo" />
								<div className="activity-percentage">{passesPercentage_B}%</div>
								<div className="activity-percentage-2">{state.passes.correct_B}/{state.passes.total_B}</div>
							</div>
						</div>
						
						{/*<div className="matchsummary">
							<div className="summary-title">Total Centers</div>
							<div className="team-percentage team-1-bar" style={{width: '41%'}}><span>13</span></div>
							<div className="team-percentage team-2-bar" style={{width: '59%'}}><span>19</span></div>
						</div>
						
						<div className="matchsummary">
							<div className="summary-title">Completed Centers</div>
							<div className="team-percentage team-1-bar" style={{width: '45%'}}><span>4</span></div>
							<div className="team-percentage team-2-bar" style={{width: '55%'}}><span>5</span></div>
						</div>*/}
						
						<section className="section-title">Clashes</section>
						<div className="sub-title">
							<div className="sub-sectiontitle-1">Completed Entries</div>
							<div className="sub-sectiontitle-2">Fouls Committed / Total</div>
						</div>
						<div className="box-module">
							<div className="team-box">
								<img src={state.logo.teamA} className="box-module-img" alt="team logo" />
								<div className="activity-percentage">{foul_percent_A}%</div>
								<div className="activity-percentage-2">{state.fouls.foulA}/{state.fouls.foulA + state.fouls.foulB}</div>
							</div>
							
							<div className="team-box">
								<img src={state.logo.teamB} className="box-module-img" alt="team logo" />
								<div className="activity-percentage">{foul_percent_B}%</div>
								<div className="activity-percentage-2">{state.fouls.foulB}/{state.fouls.foulA + state.fouls.foulB}</div>
							</div>
						</div>
						<div className="matchsummary">
							<div className="summary-title">Duels Won</div>
							<div className="team-percentage team-1-bar" style={{width: '45%'}}><span>20</span></div>
							<div className="team-percentage team-2-bar" style={{width: '55%'}}><span>24</span></div>
						</div>
						<div className="matchsummary">
							<div className="summary-title">Aerial Duels Won</div>
							<div className="team-percentage team-1-bar" style={{width: '50%'}}><span>8</span></div>
							<div className="team-percentage team-2-bar" style={{width: '50%'}}><span>8</span></div>
						</div>
						<div className="matchsummary">
							<div className="summary-title">Dribbles Completed</div>
							<div className="team-percentage team-1-bar" style={{width: '33%'}}><span>2</span></div>
							<div className="team-percentage team-2-bar" style={{width: '67%'}}><span>4</span></div>
						</div>
						
						<section className="section-title">Defending</section>
						<div className="matchsummary">
							<div className="summary-title">Interceptions</div>
							<div className="team-percentage team-1-bar" style={{width: int_pcntg_A+'%'}}><span>{state.defending.interception_A}</span></div>
							<div className="team-percentage team-2-bar" style={{width: int_pcntg_B+'%'}}><span>{state.defending.interception_B}</span></div>
						</div>
						<div className="matchsummary">
							<div className="summary-title">Clearance</div>
							<div className="team-percentage team-1-bar" style={{width: clren_pcntg_A+'%'}}><span>{state.defending.clearance_A}</span></div>
							<div className="team-percentage team-2-bar" style={{width: clren_pcntg_B+'%'}}><span>{state.defending.clearance_B}</span></div>
						</div>
						
						<section className="section-title">Discipline</section>
						<div className="matchsummary">
							<div className="summary-title">Fouls</div>
							<div className="team-percentage team-1-bar" style={{width: foul_percent_A+'%'}}><span>{state.fouls.foulA}</span></div>
							<div className="team-percentage team-2-bar" style={{width: foul_percent_B+'%'}}><span>{state.fouls.foulB}</span></div>
						</div>
						<div className="matchsummary">
							<div className="summary-title">Yellow Cards</div>
							<div className="team-percentage team-1-bar" style={{width: yellow_pcntg_A+'%'}}><span>{state.cards.yellow_A}</span></div>
							<div className="team-percentage team-2-bar" style={{width: yellow_pcntg_B+'%'}}><span>{state.cards.yellow_B}</span></div>
						</div>
						<div className="matchsummary">
							<div className="summary-title">Red Cards</div>
							<div className="team-percentage team-1-bar" style={{width: '50%'}}><span>{state.cards.red_A}</span></div>
							<div className="team-percentage team-2-bar" style={{width: '50%'}}><span>{state.cards.red_B}</span></div>
						</div>
					</div>
				)
			} else {
				return (
					<ShowStatistics state={state} />
				)
			}
		}
		
		return (
			<ShowAllElements partial={this.props.partial} state={this.state} />
		)
	}
}

function ShowStatistics(props) {
	const state = props.state;
	let chartdata = [['Team', 'Possesion'], ['TeamA', state.possesion.teamA], ['TeamB', state.possesion.teamB]];
	
	return(<div className="statistics">
		<Chart
			chartType="PieChart"
			data= {chartdata}
			options={{pieHole: 0.7,
					legend: "none",
					pieStartAngle: 180,
					pieSliceTextStyle: {
					color: 'transparent',
				},
			}}
			graph_id="PieChart"
			width="100%"
			height="160px"
		/>
		
		<div className="chartlegend leftside"><span>{state.possesion.teamA}%</span></div>
		<div className="chartlegend rightside"><span>{state.possesion.teamB}%</span></div>
		
		{/*<div className="match-total">
			<span className="team-matchtotal num rightaligned">13</span>
			<span className="team-matchtotal">Total Matches</span>
			<span className="team-matchtotal num leftaligned">15</span>
		</div>*/}
	</div>)
}