import React from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

import './innerpages.css';

import Banner from '../banner/banner';
import HeaderWithBack from '../headerwithback/headerwithback';

/*import PageShell from '../innerPageShell/innerPageShell';*/
import asyncComponent from "../AsyncComponent";
/*import MainEvent from '../mainevent/mainevent';
import Commentaries from '../commentries/commentries';
import TopPlayers from '../topplayers/topplayers';
import Positions from '../positions/positions';
import Lastfivematches from '../lastfivematches/lastfivematches';
import BallPossesion from '../ballpossesion/ballpossesion';
import Formation from '../formation/formation';
import Facetoface from '../facetoface/facetoface';*/

const MainEvent = asyncComponent(() => import('../mainevent/mainevent'));
const Commentaries = asyncComponent(() => import('../commentries/commentries'));
const TopPlayers = asyncComponent(() => import('../topplayers/topplayers'));
const Positions = asyncComponent(() => import('../positions/positions'));
const Lastfivematches = asyncComponent(() => import('../lastfivematches/lastfivematches'));
const BallPossesion = asyncComponent(() => import('../ballpossesion/ballpossesion'));
const Formation = asyncComponent(() => import('../formation/formation'));
const Facetoface = asyncComponent(() => import('../facetoface/facetoface'));

class Innerpages extends React.Component {
	
	constructor(props){
		super(props);
		this.state = {
			activeTab: '',
			activeIndex: '',
			inner_pages_arr: []
		}
	}
	
	componentWillMount(){
		const innerpages_arr = [
			{page_path: 'MainEvent', tab_name: 'Main Event'},
			/*{page_path: 'Commentaries', tab_name: 'Commentaries'},*/
			{page_path: 'Positions', tab_name: 'Positions'},
			{page_path: 'Formation', tab_name: 'Formation'},
			{page_path: 'BallPossesion', tab_name: 'Ball Possesion'},
			{page_path: 'Lastfivematches', tab_name: 'Last 5 Matches'},
			/*{page_path: 'TopPlayers', tab_name: 'Top Players'},*/
			{page_path: 'Facetoface', tab_name: 'Face to face'}
		];
		//console.log(this.props);
		innerpages_arr.map((data, index) => {
			if(this.props.location.state!==undefined && data.page_path === this.props.location.state.selected) {
				this.setState({
					activeIndex : index
				});
			}
			else {
				
			}
		});
		
		this.setState({
			inner_pages_arr : innerpages_arr,
			activeTab : this.props.location.state!==undefined?this.props.location.state.selected:'MainEvent'
		}, function(){
			//let activeElm = document.getElementsByClassName('activetab');
		})
	}
	
	componentDidMount(){
		var selected_index = this.state.activeIndex;
		var scrollmenu = document.getElementById('scrollmenu');
		//console.log(scrollmenu.scrollLeft, (window.innerWidth/3));
		setTimeout(() => (scrollmenu.scrollLeft += (selected_index-1)*(window.innerWidth/3)), 150);
	}
	
	handleClick(_event, activetab, index) {
		var scrollmenu = document.getElementById('scrollmenu');
		//console.log(scrollmenu.scrollLeft, (window.innerWidth/3));
		
		var scroll_len;
		if(index*(window.innerWidth/3) > scrollmenu.scrollLeft) {
			scroll_len = ((index-1)*(window.innerWidth/3)) - scrollmenu.scrollLeft;
			setTimeout(() => (scrollmenu.scrollLeft += scroll_len), 150);
		}
		else {
			scroll_len = scrollmenu.scrollLeft-((index-1)*(window.innerWidth/3));
			setTimeout(() => (scrollmenu.scrollLeft -= scroll_len), 150);
		}
		
		/*if(index>this.state.activeIndex) {
			var scroll_len = (index-this.state.activeIndex)*(window.innerWidth/3);
			setTimeout(() => (scrollmenu.scrollLeft += scroll_len), 150);
		}
		else {
			var scroll_len = (this.state.activeIndex-index)*(window.innerWidth/3);
			setTimeout(() => (scrollmenu.scrollLeft -= scroll_len), 150);
		}*/
		
		this.setState({
			activeTab : activetab,
			activeIndex : index
		});
	}
	
	render() {
		const match = this.props.match;
		//console.log(match);
		const activeTab = this.state.activeTab;

		return (
			
			<div className="todays_match">
				<HeaderWithBack path="/MatchInterior" />
				<main className="App-body">
					<Banner />
					
					<Router>
						<div className="innerpages_route">
							<div id="scrollmenu">
								{
									this.state.inner_pages_arr.map((page, index) => {
										return(
											<p key={index} className={activeTab===page.page_path ? 'activetab' : null} onClick={(e) => this.handleClick(e, page.page_path, index)}>
												<Link to={`/innerpages/${page.page_path}`}>{page.tab_name}</Link>
											</p>
										);
									})
								}
							</div>
							
							<Switch>
								<Route exact path={`${match.path}/MainEvent`} component={MainEvent} />
								<Route path={`${match.path}/Commentaries`} component={Commentaries} />
								<Route path={`${match.path}/Positions`} component={Positions} />
								<Route path={`${match.path}/Formation`} component={Formation} />
								<Route path={`${match.path}/BallPossesion`} component={BallPossesion} />
								<Route path={`${match.path}/Lastfivematches`} component={Lastfivematches} />
								<Route path={`${match.path}/TopPlayers`} component={TopPlayers} />
								<Route path={`${match.path}/Facetoface`} component={Facetoface} />
							</Switch>
						</div>
					</Router>
				</main>
			</div>
		);
	}
}

export default Innerpages;